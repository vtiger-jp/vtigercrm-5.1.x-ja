<?php
/** YOUR LICENSE TEXT HERE **/
global $currentModule;

echo "<B>You have successfully installed extension module!<B>";

?>
